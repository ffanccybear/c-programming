#include<stdio.h>
int A[100];
int prime_range(int a, int b){
	int i=a, j,m=0, t=0, e;
	for(i;i<=b;i++){
		e=0;
		for(j=2;j<=i;j++){
			if(i%j!=0)
			e++;
		}
		if(e==i-2||i==2){
			m++;
			A[t]=i;
			t++;
		}
}
	return m;
}
int main(){
	int a, b, q;
	scanf("%d %d", &a, &b);
	q=prime_range(a,b);
	printf("%d shirheg anhni too baina.", q);
	for(int i=0; i<q;i++)
	printf("\n%d", A[i]);
}
