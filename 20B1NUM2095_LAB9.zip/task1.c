#include<stdio.h>
int is_even(int k){
  if(k%2==0){
    return 1 ;
  }
  else {
    return 0 ;
  }
}
int main(){
  int n ;
  scanf("%d", &n) ;
  for(int i=1;i<=n;i++){
    if(is_even(i)==0){
      printf("%d \n", i) ;
    }
  }
  return 0; 
}
