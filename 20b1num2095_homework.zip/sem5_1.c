#include<stdio.h>
int main(){
  int t ;
  int check ;
  int tmp ; 
  int cnt = 0 ;
  scanf("%d", &t) ;
  tmp = t ;
  for(int i=1;i<=t;i++){
    if(tmp%i==0){
      check = 1 ;
      printf("%d \n", i) ;
    }
    else check = 0 ;
  }
  return 0;
}
