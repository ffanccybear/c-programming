#include<stdio.h>

int main(){
    int ehlel, odor, tooluur, honog, ehnii_mor = 1;
    printf("Ta ehleh garagaa oruulna uu: ");
    scanf("%d", &ehlel);
    printf("Ta sarin honogoo oruulna uu: ");
    scanf("%d", &honog);
    printf("\n\n");
    printf(" MON | TUE | WED | THU | FRI | SAT | SUN\n");
    for(odor = 1; odor <= honog; odor++)
    {
        if(ehnii_mor)
        {
            if(ehlel > odor){
                printf("      ");
            }
            else{
                printf("   1  ");
                odor = 1;
                ehnii_mor = 0;
                tooluur = ehlel;
            }
        }
        else{
            if(tooluur == 7){
                tooluur = 1;
                printf("\n");
            }
            else{
                tooluur++;
            }
            if(odor < 10)
            {
                printf(" ");}
            printf("  %d  ",odor);
        }
    }
}
