#include<stdio.h>
int main(){
  int n ;
  int s_mur = 0 ;
  int s_bagana = 0 ;
  int s_d1 = 0 ; 
  int s_d2 = 0 ;
  scanf("%d", &n) ;
  int arr[n][n] ;
  for(int i=1;i<=n;i++){
    for(int j=1;j<=n;j++){
      scanf("%d", &arr[i][j]) ;
    }
  }
  for(int i=1;i<=n;i++){
    s_mur = 0; 
    for(int j=1;j<=n;j++){
      s_mur += arr[i][j] ; 
   }
    printf("%d-r murnii niilber %d\n", i, s_mur) ;
  }
  for(int j=1;j<=n;j++){
    s_bagana = 0 ;
    for(int i=1;i<=n;i++){
      s_bagana += arr[i][j] ; 
    }
    printf("%d-r baganii niilber %d\n", j, s_bagana) ;
  }
  for(int i=1;i<=n;i++){
    s_d1 += arr[i][i] ;   
  }
  for(int i=1;i<=n;i++){
       s_d2 += arr[i][n-i+1] ;
    
  }
  printf("gol diagonaliin niilber: %d\n", s_d1) ;
  printf("esreg diagonaliin niilber: %d\n", s_d2) ;
  return 0;
}
