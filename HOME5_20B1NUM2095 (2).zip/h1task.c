#include <stdio.h>

int main(void) {
	int n,m;
	scanf("%d %d",&n,&m);
	int A[n],B[m],C[n+m];
	for(int i=0;i<n;i++){
		scanf("%d",&A[i]);
	}
	for(int i=0;i<m;i++){
		scanf("%d",&B[i]);
	}
	int j=0;
	for(int i=0;i<n;i++){
		int c=1;
		for(int h = 0; h<j;h++){
			if(A[i]==C[h]) c=0;
		}
		if(c==1){
			C[j]=A[i];
			j++;
		}
	}
	for(int i=0;i<m;i++){
		int c=1;
		for(int h = 0; h<j;h++){
			if(B[i]==C[h]) c=0;
		}
		if(c==1){
			C[j]=B[i];
			j++;
		}
	}
	for(int i=0;i<j;i++) printf("%d ",C[i]);
	return 0;
}

