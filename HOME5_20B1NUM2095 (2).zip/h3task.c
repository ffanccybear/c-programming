#include<stdio.h>

int main(){
	int m,n,k;
	scanf("%d%d%d",&m,&k,&n);
	int arr[k][n][m];
	int cnt=1;
	for(int i=0; i<k;i++){
		for(int j=0;j<n;j++){
			for(int h=0;h<m;h++){
				arr[i][j][h]=cnt;
				cnt++;
			}
		}
	}
	
	for(int i=0; i<k;i++){
		printf("%d-r orts \n",i+1);
		for(int j=0;j<n;j++){
			printf("%d-r davhar \n",j+1);
			for(int h=0;h<m;h++){
				printf("%d ",arr[i][j][h]);
			}
			printf("\n");
		}
	}
	
	return 0;
}
