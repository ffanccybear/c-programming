#include<stdio.h>
int main(){
  int t ;
  int sum = 0;
  scanf("%d", &t) ;
  for(int i=1;i<=t;i++)
      if(i%2==0){
        sum += i ;
      }
  printf("%d\n",sum) ;
  return 0;
}
