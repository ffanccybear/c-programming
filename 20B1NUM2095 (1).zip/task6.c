#include<stdio.h>
int main(){
  int t ;
  scanf("%d", &t) ;
  int sum = 0 ;
  for(int i=0;i<t;i++){
    sum += i ;
  }
  printf("%d\n",sum) ;
  return 0;
}
