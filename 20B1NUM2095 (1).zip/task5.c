#include<stdio.h>
int main(){
  double t ;
  double sol;
  scanf("%lf", &t) ;
  for(int i=0;i<=t;i++){
      sol = 1.8*i+32 ;
      printf("%d %0.3f\n",i, sol) ;
  }
  return 0;
  
}
