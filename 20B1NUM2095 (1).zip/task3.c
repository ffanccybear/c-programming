#include<stdio.h>
int main(){
  int n,i=0 ;
  scanf("%d", &n);
  do {
    printf("%d ", i) ;
    i++ ;
  } while(i<=n);
  printf("\n") ;
  return 0;
}
