#include<stdio.h>
int main(){
  int t ;
  scanf("%d", &t) ;
  for(int i=0;i<t;i++){
    printf("programming in c\n") ;
  }
  return 0;
}
