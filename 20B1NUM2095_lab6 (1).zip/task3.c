#include<stdio.h>

int main(){
	int n,m,i,j;
	scanf("%d %d",&n,&m);
	int A[n],B[m],C[n+m+1];
	j=0;
	for(i=0;i<n;i++){
		scanf("%d",&A[i]);
		C[j]=A[i];
		j++;
	}
	for(i=0;i<m;i++){
		scanf("%d",&B[i]);
		C[j]=B[i];
		j++;
	}
	
	for(i=0;i<n+m;i++) printf("%d ",C[i]); 
	
	
	return 0;
}
