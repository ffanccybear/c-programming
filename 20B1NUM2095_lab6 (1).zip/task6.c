#include<stdio.h>
int main(){
  int m, n ;
  int ans =0;
  int mur , bagana ;
  int x ;
  scanf("%d %d", &n, &m) ;
  scanf("%d", &x) ;
  int arr[n+1][m+1] ;
  for(int i=1;i<=n;i++){
    for(int j=1;j<=m;j++){
      scanf("%d", &arr[i][j]) ;
    }
  }
  
  for(int i=1;i<=n;i++){
    
    for(int j=1;j<=m;j++){
      if(x==arr[i][j]){
        ans = 1 ;
        mur = i ;
        bagana = j ;
        printf("%d-r murnii %d-r bagana\n", mur, bagana) ;
      }
    }
  }
  if(ans==0){
    printf("-1") ;
  }
  return 0;
 }
