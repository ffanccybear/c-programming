#include<stdio.h>
#include<math.h>

int count(int n){
    int cnt = 0 ;
    for(int i=1;i<=sqrt(n);i++){
        if(n%i==0){
            if(n/i==i){
                cnt++ ;
            }
            else{
                cnt = cnt + 2 ;
            }
        }
    }
    return cnt ;
}
int main(){
    int n ;
    scanf("%d", &n) ;
    int m = count(n) ;
    printf("%d", m) ;
    return 0;
}