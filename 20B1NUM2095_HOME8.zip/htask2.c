#include<stdio.h>

int digit_sum(int a){
	int s=0;
	while(a>0){
		s=s+a%10;
		a=a/10;
	}
	return s;
}
int main(){
	int n, o;
	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		o=digit_sum(i);
		if(i%o==0){
			printf("\n%d", i);
		}
	}
	return 0;
}
